name=TMWebRock$(uuidgen)
zip -r $name *.*
mv $name.zip ../bck/
