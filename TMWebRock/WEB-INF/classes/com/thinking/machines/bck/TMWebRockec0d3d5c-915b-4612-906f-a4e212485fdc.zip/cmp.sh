javac -classpath /opt/tomcat/lib/*:/opt/tomcat/webapps/TMWebRock/WEB-INF/classes:/opt/tomcat/webapps/TMWebRock/WEB-INF/lib/*:. *.java
